# fft-komen-aja
* install kaya biasa ok
* kalo eror ada bacaan "error-cannot find module instagram-private-api" 
* install dlu mnual iyh
* npm install && npm audit fix && npm update && npm i -g update
* baru jalanin node komen.js
